<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class regularUser extends Model
{
    //
}
