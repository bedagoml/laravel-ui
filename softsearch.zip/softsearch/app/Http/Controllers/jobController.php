<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


use App\Http\Resources\jobResource;

use App\job;

use App\Http\Requests;

class jobController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $emp = job::all();

        return jobResource::collection($emp);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
         {

        $emp = new job;

        $emp->task = $request->input('task');

        $emp->timetaken = $request->input('timetaken');

        $emp->date = $request->input('date');

        $emp->save();

        return new jobResource($emp);

    }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         {

        $emp = new job;

        $emp->task = $request->input('task');

        $emp->timetaken = $request->input('timetaken');

        $emp->date = $request->input('date');

        $emp->save();

        return new jobResource($emp);

    }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
   {

         $article = job::find($id); //id comes from route

        if( $article ){

            return new jobResource($article);

        }

        return "Task Not found"; // temporary error

    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
   {

        $emp = job::find($id);

         $emp->task = $request->input('task');

        $emp->timetaken = $request->input('timetaken');

        $emp->date = $request->input('date');

        $emp->save();

        return new jobResource($emp);

    }



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
     {

        $emp = job::findOrfail($id);

        if($emp->delete()){

            return  new jobResource($emp);

        }

        return "Error while deleting";
    }

}
