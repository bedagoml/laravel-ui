<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class task extends Model
{
  protected $fillable = ['task', 'time-taken', 'date'];
}
